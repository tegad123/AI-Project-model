# ── AI MODEL POST GENERATOR — CONFIG ────────────────────────────────────────
# Keep this file private. Do not share publicly.
# Share only with trusted collaborators.

# Path to your reference model image
AMBER_DEFAULT_PATH = r"C:\Users\Marlo\OneDrive\Ref_model\Amber.png"

# WaveSpeed API key
WAVESPEED_API_KEY = "bb4a800599c06d0ff42d72c9ac86b3edc5081d8b03ca6b0b859e2281c199c0d1"

# Anthropic API key (for scene analysis without browser bot)
# Get yours at: console.anthropic.com
ANTHROPIC_API_KEY = ""

# WaveSpeed model to use
WAVESPEED_MODEL = "google/nano-banana-pro/edit"

# Image output settings — do not change unless WaveSpeed updates pricing
ASPECT_RATIO   = "9:16"
RESOLUTION     = "4k"
COST_PER_IMAGE = 0.204

# Model description — used in the generation prompt
MODEL_NAME = "Amber"
MODEL_DESCRIPTION = (
    "Amber: young woman, warm olive skin, very long thick jet black wavy hair with "
    "voluminous beach waves falling past bust, large hazel amber-brown eyes, bold defined "
    "dark eyebrows, full lips with nude-pink color, natural glam makeup with warm bronze "
    "eyeshadow and lash extensions, diamond pave cross pendant necklace on silver chain."
)

# Chrome remote debugging port — must match your Chrome for AI shortcut
CHROME_DEBUG_PORT = 9222
